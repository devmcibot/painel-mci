export default function Home() {
  return (
    <main style={{padding:24}}>
      <h1>MCI – Login (demo)</h1>
      <p>Acesse <a href="/admin">/admin</a> (admin)</p>
      <p>Acesse <a href="/medico">/medico</a> (médico)</p>
    </main>
  );
}
